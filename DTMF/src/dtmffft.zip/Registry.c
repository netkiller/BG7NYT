// REGISTRY.C (c) 2004 Howard Long (G6LVB), Hanlincrest Ltd. All rights reserved.
// 72 Princes Gate
// London SW7 2PA
// United Kingdom
// howard@hanlincrest.com
// Free for educational and non-profit use. For commercial use please contact the author.

#include <windows.h>

#include "registry.h"

static const char _szHKLMAppRoot[]="Software\\Hanlincrest\\DTMFFFT";

BOOL RegGetString(char *pszKey,char *pszData,int nLen)
{
	DWORD dwLen=nLen;
	DWORD dwType=REG_SZ;
	HKEY hk=NULL;
	DWORD dw;

	if (RegCreateKeyEx(HKEY_LOCAL_MACHINE,_szHKLMAppRoot,0,NULL,REG_OPTION_NON_VOLATILE,KEY_QUERY_VALUE | KEY_SET_VALUE,NULL,&hk,&dw))
	{
		return FALSE;
	}
	if (RegQueryValueEx(hk,pszKey,NULL,&dwType,pszData,&dwLen)!=ERROR_SUCCESS)
	{
		RegCloseKey(hk);
		hk=NULL;
		return FALSE;
	}
	RegCloseKey(hk);
	hk=NULL;
	return TRUE;
}

BOOL RegSetString(char *pszKey,char *pszData)
{
	HKEY hk=NULL;
	DWORD dw;

	if (RegCreateKeyEx(HKEY_LOCAL_MACHINE,_szHKLMAppRoot,0,NULL,REG_OPTION_NON_VOLATILE,KEY_QUERY_VALUE | KEY_SET_VALUE,NULL,&hk,&dw))
	{
		return FALSE;
	}
	if (RegSetValueEx(hk,pszKey,0,REG_SZ,pszData,strlen(pszData)+1)!=ERROR_SUCCESS)
	{
		RegCloseKey(hk);
		hk=NULL;
		return FALSE;
	}
	RegCloseKey(hk);
	hk=NULL;
	return TRUE;
}
