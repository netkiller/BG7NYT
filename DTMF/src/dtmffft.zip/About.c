// ABOUT.C (c) 2004 Howard Long (G6LVB), Hanlincrest Ltd. All rights reserved.
// 72 Princes Gate
// London SW7 2PA
// United Kingdom
// howard@hanlincrest.com
// Free for educational and non-profit use. For commercial use please contact the author.

#include <windows.h>

#include "resource.h"

#include "about.h"

static LRESULT CALLBACK AboutDlg(HWND hdlg,UINT message,WPARAM wParam,LPARAM lParam)
{
	switch (message) 
	{
		case WM_COMMAND:
			switch (LOWORD(wParam))
			{
				case IDOK:
				case IDCANCEL:
					EndDialog(hdlg, TRUE);
					break;
				default:
					break;
			}
			break;
		default:
			break;
	}
	return FALSE;
}

void About(HWND hdlg, HINSTANCE hinst)
{
	DialogBox(hinst,MAKEINTRESOURCE(IDD_ABOUT),hdlg,AboutDlg);
}
