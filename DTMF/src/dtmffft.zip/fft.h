// FFT.H (c) 2004 Howard Long (G6LVB), Hanlincrest Ltd. All rights reserved.
// 72 Princes Gate
// London SW7 2PA
// United Kingdom
// howard@hanlincrest.com
// Free for educational and non-profit use. For commercial use please contact the author.

typedef __int8 S8, *PS8;
typedef unsigned __int8 U8, *PU8;
typedef __int16 S16, *PS16;
typedef unsigned __int16 U16, *PU16;
typedef __int32 S32, *PS32;
typedef unsigned __int32 U32, *PU32;
typedef __int64 S64, *PS64;
typedef unsigned __int64 U64, *PU64;

typedef struct
{
	S16 s16Sin;
	S16 s16Cos;
} FFTSINCOSSTRUCT, *PFFTSINCOSSTRUCT;

typedef union
{
	PS16 ps16SinCos;
	PFFTSINCOSSTRUCT pfscs;
} FFTSINCOSUNION;

typedef struct
{
	CRITICAL_SECTION cs;
	int nLen; // Number of bins
	BOOL bClip; // Input too high?
	S16 *ps16BitRev; // Array to hold bit reversal table
	S32 s32Average; // Mean level
	S32 s32Max; // Max level
	FFTSINCOSUNION fscu; // Array of 16 bit integer-ized sin and cos values
	S16 *ps16Window; // Array to hold Window function values
	
} FFTSTRUCT, *PFFTSTRUCT;

extern void FFTTerm(PFFTSTRUCT pfs);
extern BOOL FFTInit(PFFTSTRUCT pfs,int nLen);
extern void FFTRun(PFFTSTRUCT pfs,PS16 ps16BufferIn,PS32 ps32BufferOut);
extern S32 FFTGetMax(PFFTSTRUCT pfs);
extern S32 FFTGetAverage(PFFTSTRUCT pfs);
